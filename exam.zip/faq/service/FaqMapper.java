package egovframework.example.faq.service;

import java.util.List;

import org.egovframe.rte.psl.dataaccess.mapper.Mapper;

import egovframework.example.common.Criteria;
@Mapper
public interface FaqMapper {
	public List<?> selectFaqList(Criteria criteria); // 전체 조회
	public int selectFaqListTotCnt(Criteria criteria); // 총 개수 구하기

}
