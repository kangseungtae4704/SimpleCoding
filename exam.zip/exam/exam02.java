/**
 * 
 */
package egovframework.example.exam;



/**
 * @author user
 * 2번 문제풀이 
 * @Log4j2
    @Controller
     public class DeptController {
//	서비스 클래스 가져오기
	@Autowired
	private DeptService deptService;
	추가사항 
	1)@Controller 
	2)@Autowired
 */
